#!/bin/bash
if [ $# -ne 1 ];  then
    echo "Wrong number of paramethers"
else 
    if [ -f $1 ]; then
        
    else
        echo "can't access the file"
    fi
fi